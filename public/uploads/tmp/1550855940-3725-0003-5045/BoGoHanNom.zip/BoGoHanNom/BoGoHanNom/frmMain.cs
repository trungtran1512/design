﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BoGoHanNom
{
    public partial class frmMain : Form
    {
        private string table;
        private int count = 0;
        private string strChuoi = "";
        private string strButton1, strButton2, strButton3, strButton4, strButton5, strButton6, strButton7, strButton8, strButton9, strButton0;
        int page;
        private string strConnect = @"Data Source=KENDYHAI\SQLEXPRESS;Initial Catalog=db_HanNom;Integrated Security=True";
        private SqlConnection con;

        private void btNum1_Click(object sender, EventArgs e)
        {
            if (strButton1 != "")
            {
                strChuoi = strChuoi + "" + strButton1 + " ";
                update_rtb_Text();
            }

        }

        //private SqlDataAdapter da = new SqlDataAdapter();
        public frmMain()
        {
            InitializeComponent();
        }

        private void btNum2_Click(object sender, EventArgs e)
        {
            if (strButton2 != "")
            {
                strChuoi = strChuoi + "" + strButton2 + " ";
                update_rtb_Text();
            }
        }

        private void btNum3_Click(object sender, EventArgs e)
        {
            if (strButton3 != "")
            {
                strChuoi = strChuoi + "" + strButton3 + " ";
                update_rtb_Text();
            }
        }

        private void btNum4_Click(object sender, EventArgs e)
        {
            if (strButton4 != "")
            {
                strChuoi = strChuoi + "" + strButton4 + " ";
                update_rtb_Text();
            }
        }

        private void btNum5_Click(object sender, EventArgs e)
        {
            if (strButton5 != "")
            {
                strChuoi = strChuoi + "" + strButton5 + " ";
                update_rtb_Text();
            }
        }

        private void btNum6_Click(object sender, EventArgs e)
        {
            if (strButton6 != "")
            {
                strChuoi = strChuoi + "" + strButton6 + " ";
                update_rtb_Text();
            }
        }

        private void btNum7_Click(object sender, EventArgs e)
        {
            if (strButton7 != "")
            {
                strChuoi = strChuoi + "" + strButton7 + " ";
                update_rtb_Text();
            }
        }

        private void btNum8_Click(object sender, EventArgs e)
        {
            if (strButton8 != "")
            {
                strChuoi = strChuoi + "" + strButton8 + " ";
                update_rtb_Text();
            }
        }

        private void btNum9_Click(object sender, EventArgs e)
        {
            if (strButton9 != "")
            {
                strChuoi = strChuoi + "" + strButton9 + " ";
                update_rtb_Text();
            }
        }

        private void btNum0_Click(object sender, EventArgs e)
        {
            if (strButton0 != "")
            {
                strChuoi = strChuoi + "" + strButton0 + " ";
                update_rtb_Text();
            }
        }

        //Xử lý phím tắt để gọi
        private void frmMain_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                if (strButton1 != "")
                {
                    strChuoi = strChuoi + "" + strButton1 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F2)
            {
                if (strButton2 != "")
                {
                    strChuoi = strChuoi + "" + strButton2 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F3)
            {
                if (strButton3 != "")
                {
                    strChuoi = strChuoi + "" + strButton3 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F4)
            {
                if (strButton4 != "")
                {
                    strChuoi = strChuoi + "" + strButton4 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F5)
            {
                if (strButton5 != "")
                {
                    strChuoi = strChuoi + "" + strButton5 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F6)
            {
                if (strButton6 != "")
                {
                    strChuoi = strChuoi + "" + strButton6 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F7)
            {
                if (strButton7 != "")
                {
                    strChuoi = strChuoi + "" + strButton7 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F8)
            {
                if (strButton8 != "")
                {
                    strChuoi = strChuoi + "" + strButton8 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F9)
            {
                if (strButton9 != "")
                {
                    strChuoi = strChuoi + "" + strButton9 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F10)
            {
                if (strButton0 != "")
                {
                    strChuoi = strChuoi + "" + strButton0 + " ";
                    update_rtb_Text();
                }
            }
        }

        private void txtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                if (strButton1 != "")
                {
                    strChuoi = strChuoi + "" + strButton1 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F2)
            {
                if (strButton2 != "")
                {
                    strChuoi = strChuoi + "" + strButton2 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F3)
            {
                if (strButton3 != "")
                {
                    strChuoi = strChuoi + "" + strButton3 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F4)
            {
                if (strButton4 != "")
                {
                    strChuoi = strChuoi + "" + strButton4 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F5)
            {
                if (strButton5 != "")
                {
                    strChuoi = strChuoi + "" + strButton5 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F6)
            {
                if (strButton6 != "")
                {
                    strChuoi = strChuoi + "" + strButton6 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F7)
            {
                if (strButton7 != "")
                {
                    strChuoi = strChuoi + "" + strButton7 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F8)
            {
                if (strButton8 != "")
                {
                    strChuoi = strChuoi + "" + strButton8 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F9)
            {
                if (strButton9 != "")
                {
                    strChuoi = strChuoi + "" + strButton9 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F10)
            {
                if (strButton0 != "")
                {
                    strChuoi = strChuoi + "" + strButton0 + " ";
                    update_rtb_Text();
                }
            }
        }

        private void rtb_Text_TextChanged(object sender, EventArgs e)
        {
            strChuoi = rtb_Text.Text;
        }

        private void rtb_Text_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                if (strButton1 != "")
                {
                    strChuoi = strChuoi + "" + strButton1 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F2)
            {
                if (strButton2 != "")
                {
                    strChuoi = strChuoi + "" + strButton2 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F3)
            {
                if (strButton3 != "")
                {
                    strChuoi = strChuoi + "" + strButton3 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F4)
            {
                if (strButton4 != "")
                {
                    strChuoi = strChuoi + "" + strButton4 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F5)
            {
                if (strButton5 != "")
                {
                    strChuoi = strChuoi + "" + strButton5 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F6)
            {
                if (strButton6 != "")
                {
                    strChuoi = strChuoi + "" + strButton6 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F7)
            {
                if (strButton7 != "")
                {
                    strChuoi = strChuoi + "" + strButton7 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F8)
            {
                if (strButton8 != "")
                {
                    strChuoi = strChuoi + "" + strButton8 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F9)
            {
                if (strButton9 != "")
                {
                    strChuoi = strChuoi + "" + strButton9 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F10)
            {
                if (strButton0 != "")
                {
                    strChuoi = strChuoi + "" + strButton0 + " ";
                    update_rtb_Text();
                }
            }
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbType.SelectedIndex)
            {
                case 0:
                    table = "tbl_nom";
                    loadButtonNum();
                    break;
                case 1:
                    table = "tbl_han";
                    loadButtonNum();
                    break;
            }
        }

        private void loadButtonNum()
        {
            try
            {
                count = 0;

                //Kết nối DB
                con = new SqlConnection(strConnect);
                con.Open();

                string strTXTInput;
                strTXTInput = txtInput.Text;

                //Gọi tất cả các ký tự mà hàm cần để 
                string strsql2 = "select isnull(count([id]),0) as count from " + table + " where [ime] = N'" + strTXTInput + "'";
                SqlDataAdapter da = new SqlDataAdapter(strsql2, con);
                DataTable dt = new DataTable();
                //Lấy số lượng
                SqlCommand comm = new SqlCommand(strsql2, con);
                Int32 iSL;
                iSL = (Int32)comm.ExecuteScalar();

                //Tính page

                page = (int)(iSL / 10);

                loadlblPage();
                if (iSL > 10)
                {
                    btNumUp.Enabled = true;

                    btNumBack.Enabled = false;


                }
                else
                {
                    btNumUp.Enabled = false;

                    btNumBack.Enabled = false;
                }

                string strsql = "select top 10 * from " + table + " where [ime] = N'" + strTXTInput + "' order by id";



                da = new SqlDataAdapter(strsql, con);
                dt = new DataTable();
                da.Fill(dt);



                //Xóa các bt cũ
                clearbutton();

                for (int i = 0; i < dt.Rows.Count; i++)
                {


                    switch (i)
                    {
                        case 0:
                            btNum1.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 1:
                            btNum2.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 2:
                            btNum3.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 3:
                            btNum4.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 4:
                            btNum5.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 5:
                            btNum6.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 6:
                            btNum7.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 7:
                            btNum8.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 8:
                            btNum9.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 9:
                            btNum0.Text = dt.Rows[i]["chars"].ToString();
                            break;
                    }

                }
                con.Close();
                con.Dispose();
                con = null;
                updateButtonNum();
            }
            catch (Exception ex)
            {

                con.Close();
                con.Dispose();
                con = null;

                MessageBox.Show(ex.ToString());
            }
        }

        private void cbType_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                if (strButton1 != "")
                {
                    strChuoi = strChuoi + "" + strButton1 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F2)
            {
                if (strButton2 != "")
                {
                    strChuoi = strChuoi + "" + strButton2 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F3)
            {
                if (strButton3 != "")
                {
                    strChuoi = strChuoi + "" + strButton3 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F4)
            {
                if (strButton4 != "")
                {
                    strChuoi = strChuoi + "" + strButton4 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F5)
            {
                if (strButton5 != "")
                {
                    strChuoi = strChuoi + "" + strButton5 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F6)
            {
                if (strButton6 != "")
                {
                    strChuoi = strChuoi + "" + strButton6 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F7)
            {
                if (strButton7 != "")
                {
                    strChuoi = strChuoi + "" + strButton7 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F8)
            {
                if (strButton8 != "")
                {
                    strChuoi = strChuoi + "" + strButton8 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F9)
            {
                if (strButton9 != "")
                {
                    strChuoi = strChuoi + "" + strButton9 + " ";
                    update_rtb_Text();
                }
            }

            if (e.KeyCode == Keys.F10)
            {
                if (strButton0 != "")
                {
                    strChuoi = strChuoi + "" + strButton0 + " ";
                    update_rtb_Text();
                }
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            if (count == 0)
            {
                btNumBack.Enabled = false;
            }

            if (txtInput.Text == "")
            {
                btNumUp.Enabled = false;
            }
            clearbutton();
            table = "tbl_nom";

            //cbType.DisplayMember = "Type";
            //cbType.ValueMember = "Value";

            cbType.SelectedIndex = 0;

            //cbType.Items.Add(new { Text = "Chữ Nôm", Value = "tbl_nom" });
            //cbType.Items.Add(new { Text = "Chữ Hán", Value = "tbl_han" });
            //cbType.Items

        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {
            try
            {
                count = 0;

                //Kết nối DB
                con = new SqlConnection(strConnect);
                con.Open();

                string strTXTInput;
                strTXTInput = txtInput.Text;

                //Gọi tất cả các ký tự mà hàm cần để 
                string strsql2 = "select isnull(count([id]),0) as count from " + table + " where [ime] = N'" + strTXTInput + "'";
                SqlDataAdapter da = new SqlDataAdapter(strsql2, con);
                DataTable dt = new DataTable();
                //Lấy số lượng
                SqlCommand comm = new SqlCommand(strsql2, con);
                Int32 iSL;
                iSL = (Int32)comm.ExecuteScalar();

                //Tính page

                page = (int)(iSL / 10);

                loadlblPage();
                if (iSL > 10)
                {
                    btNumUp.Enabled = true;

                    btNumBack.Enabled = false;


                }
                else
                {
                    btNumUp.Enabled = false;

                    btNumBack.Enabled = false;
                }

                string strsql = "select top 10 * from " + table + " where [ime] = N'" + strTXTInput + "' order by id";



                da = new SqlDataAdapter(strsql, con);
                dt = new DataTable();
                da.Fill(dt);



                //Xóa các bt cũ
                clearbutton();

                for (int i = 0; i < dt.Rows.Count; i++)
                {


                    switch (i)
                    {
                        case 0:
                            btNum1.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 1:
                            btNum2.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 2:
                            btNum3.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 3:
                            btNum4.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 4:
                            btNum5.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 5:
                            btNum6.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 6:
                            btNum7.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 7:
                            btNum8.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 8:
                            btNum9.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 9:
                            btNum0.Text = dt.Rows[i]["chars"].ToString();
                            break;
                    }

                }
                con.Close();
                con.Dispose();
                con = null;
                updateButtonNum();
            }
            catch (Exception ex)
            {

                con.Close();
                con.Dispose();
                con = null;

                MessageBox.Show(ex.ToString());
            }
        }

        private void clearbutton()
        {

            btNum1.Text = "";
            btNum2.Text = "";
            btNum3.Text = "";
            btNum4.Text = "";
            btNum5.Text = "";
            btNum6.Text = "";
            btNum7.Text = "";
            btNum8.Text = "";
            btNum9.Text = "";
            btNum0.Text = "";
        }

        private void updateButtonNum()
        {
            strButton1 = btNum1.Text;
            strButton2 = btNum2.Text;
            strButton3 = btNum3.Text;
            strButton4 = btNum4.Text;
            strButton5 = btNum5.Text;
            strButton6 = btNum6.Text;
            strButton7 = btNum7.Text;
            strButton8 = btNum8.Text;
            strButton9 = btNum9.Text;
            strButton0 = btNum0.Text;
        }

        private void btNumUp_Click(object sender, EventArgs e)
        {

            try
            {

                //Kết nối DB
                con = new SqlConnection(strConnect);
                con.Open();

                string strTXTInput;
                strTXTInput = txtInput.Text;

                //Load Page
                count = count + 1;
                loadlblPage();

                load_buttonPage();

                string strsql = "select top 10 t.* from " + table + " t where t.[ime] = N'" + strTXTInput + "' and t.[id] not in (select top " + count * 10 + " v.[id] from " + table + " v where v.[ime] = N'" + strTXTInput + "' order by t.id) order by t.id";

                SqlDataAdapter da = new SqlDataAdapter(strsql, con);
                DataTable dt = new DataTable();
                da = new SqlDataAdapter(strsql, con);
                dt = new DataTable();
                da.Fill(dt);



                //Xóa các bt cũ
                clearbutton();

                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    switch (i)
                    {
                        case 0:
                            btNum1.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 1:
                            btNum2.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 2:
                            btNum3.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 3:
                            btNum4.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 4:
                            btNum5.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 5:
                            btNum6.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 6:
                            btNum7.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 7:
                            btNum8.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 8:
                            btNum9.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 9:
                            btNum0.Text = dt.Rows[i]["chars"].ToString();
                            break;
                    }

                }
                con.Close();
                con.Dispose();
                con = null;
                updateButtonNum();
            }
            catch (Exception ex)
            {

                con.Close();
                con.Dispose();
                con = null;

                MessageBox.Show(ex.ToString());
            }

        }

        private void loadlblPage()
        {
            lblPage.Text = "Page: " + (count + 1) + "/" + (page + 1);
        }

        private void btNumBack_Click(object sender, EventArgs e)
        {

            try
            {

                //Kết nối DB
                con = new SqlConnection(strConnect);
                con.Open();

                string strTXTInput;
                strTXTInput = txtInput.Text;

                //Load Page
                count = count - 1;
                loadlblPage();

                load_buttonPage();


                //string strsql = "select top 10 * from tbl_nom where [ime] = N'" + strTXTInput + "' order by id";
                string strsql = "select top 10 t.* from " + table + " t where t.[ime] = N'" + strTXTInput + "' and t.[id] not in (select top " + count * 10 + " v.[id] from " + table + " v where v.[ime] = N'" + strTXTInput + "' order by t.id) order by t.id";

                SqlDataAdapter da = new SqlDataAdapter(strsql, con);
                DataTable dt = new DataTable();
                da = new SqlDataAdapter(strsql, con);
                dt = new DataTable();
                da.Fill(dt);



                //Xóa các bt cũ
                clearbutton();

                for (int i = 0; i < dt.Rows.Count; i++)
                {


                    switch (i)
                    {
                        case 0:
                            btNum1.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 1:
                            btNum2.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 2:
                            btNum3.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 3:
                            btNum4.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 4:
                            btNum5.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 5:
                            btNum6.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 6:
                            btNum7.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 7:
                            btNum8.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 8:
                            btNum9.Text = dt.Rows[i]["chars"].ToString();
                            break;
                        case 9:
                            btNum0.Text = dt.Rows[i]["chars"].ToString();
                            break;
                    }

                }
                con.Close();
                con.Dispose();
                con = null;
                updateButtonNum();
            }
            catch (Exception ex)
            {

                con.Close();
                con.Dispose();
                con = null;

                MessageBox.Show(ex.ToString());
            }

        }

        private void load_buttonPage()
        {
            if (count == page)
            {
                btNumUp.Enabled = false;

            }
            else
            {
                btNumUp.Enabled = true;
            }

            if (count > 0)
            {
                btNumBack.Enabled = true;
            }
            else
            {
                btNumBack.Enabled = false;
            }
        }

        private void update_rtb_Text()
        {
            rtb_Text.Text = strChuoi;
        }



    }
}

