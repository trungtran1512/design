﻿namespace BoGoHanNom
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtb_Text = new System.Windows.Forms.RichTextBox();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btNum1 = new System.Windows.Forms.Button();
            this.btNum2 = new System.Windows.Forms.Button();
            this.btNum4 = new System.Windows.Forms.Button();
            this.btNum3 = new System.Windows.Forms.Button();
            this.btNum6 = new System.Windows.Forms.Button();
            this.btNum5 = new System.Windows.Forms.Button();
            this.btNum8 = new System.Windows.Forms.Button();
            this.btNum7 = new System.Windows.Forms.Button();
            this.btNum0 = new System.Windows.Forms.Button();
            this.btNum9 = new System.Windows.Forms.Button();
            this.btNumUp = new System.Windows.Forms.Button();
            this.btNumBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblPage = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtb_Text
            // 
            this.rtb_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_Text.Location = new System.Drawing.Point(12, 123);
            this.rtb_Text.Name = "rtb_Text";
            this.rtb_Text.Size = new System.Drawing.Size(1107, 343);
            this.rtb_Text.TabIndex = 0;
            this.rtb_Text.Text = "";
            this.rtb_Text.TextChanged += new System.EventHandler(this.rtb_Text_TextChanged);
            this.rtb_Text.KeyDown += new System.Windows.Forms.KeyEventHandler(this.rtb_Text_KeyDown);
            // 
            // cbType
            // 
            this.cbType.FormattingEnabled = true;
            this.cbType.Items.AddRange(new object[] {
            "Tiếng Việt -> Nôm",
            "Tiếng Việt -> Hán"});
            this.cbType.Location = new System.Drawing.Point(52, 12);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(121, 21);
            this.cbType.TabIndex = 1;
            this.cbType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            this.cbType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbType_KeyDown);
            // 
            // txtInput
            // 
            this.txtInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInput.Location = new System.Drawing.Point(13, 40);
            this.txtInput.Multiline = true;
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(134, 44);
            this.txtInput.TabIndex = 2;
            this.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtInput.TextChanged += new System.EventHandler(this.txtInput_TextChanged);
            this.txtInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInput_KeyDown);
            // 
            // btNum1
            // 
            this.btNum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum1.Location = new System.Drawing.Point(153, 40);
            this.btNum1.Name = "btNum1";
            this.btNum1.Size = new System.Drawing.Size(75, 44);
            this.btNum1.TabIndex = 3;
            this.btNum1.UseVisualStyleBackColor = true;
            this.btNum1.Click += new System.EventHandler(this.btNum1_Click);
            // 
            // btNum2
            // 
            this.btNum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum2.Location = new System.Drawing.Point(234, 40);
            this.btNum2.Name = "btNum2";
            this.btNum2.Size = new System.Drawing.Size(75, 44);
            this.btNum2.TabIndex = 4;
            this.btNum2.UseVisualStyleBackColor = true;
            this.btNum2.Click += new System.EventHandler(this.btNum2_Click);
            // 
            // btNum4
            // 
            this.btNum4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum4.Location = new System.Drawing.Point(396, 40);
            this.btNum4.Name = "btNum4";
            this.btNum4.Size = new System.Drawing.Size(75, 44);
            this.btNum4.TabIndex = 6;
            this.btNum4.UseVisualStyleBackColor = true;
            this.btNum4.Click += new System.EventHandler(this.btNum4_Click);
            // 
            // btNum3
            // 
            this.btNum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum3.Location = new System.Drawing.Point(315, 40);
            this.btNum3.Name = "btNum3";
            this.btNum3.Size = new System.Drawing.Size(75, 44);
            this.btNum3.TabIndex = 5;
            this.btNum3.UseVisualStyleBackColor = true;
            this.btNum3.Click += new System.EventHandler(this.btNum3_Click);
            // 
            // btNum6
            // 
            this.btNum6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum6.Location = new System.Drawing.Point(558, 40);
            this.btNum6.Name = "btNum6";
            this.btNum6.Size = new System.Drawing.Size(75, 44);
            this.btNum6.TabIndex = 8;
            this.btNum6.UseVisualStyleBackColor = true;
            this.btNum6.Click += new System.EventHandler(this.btNum6_Click);
            // 
            // btNum5
            // 
            this.btNum5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum5.Location = new System.Drawing.Point(477, 40);
            this.btNum5.Name = "btNum5";
            this.btNum5.Size = new System.Drawing.Size(75, 44);
            this.btNum5.TabIndex = 7;
            this.btNum5.UseVisualStyleBackColor = true;
            this.btNum5.Click += new System.EventHandler(this.btNum5_Click);
            // 
            // btNum8
            // 
            this.btNum8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum8.Location = new System.Drawing.Point(720, 40);
            this.btNum8.Name = "btNum8";
            this.btNum8.Size = new System.Drawing.Size(75, 44);
            this.btNum8.TabIndex = 10;
            this.btNum8.UseVisualStyleBackColor = true;
            this.btNum8.Click += new System.EventHandler(this.btNum8_Click);
            // 
            // btNum7
            // 
            this.btNum7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum7.Location = new System.Drawing.Point(639, 40);
            this.btNum7.Name = "btNum7";
            this.btNum7.Size = new System.Drawing.Size(75, 44);
            this.btNum7.TabIndex = 9;
            this.btNum7.UseVisualStyleBackColor = true;
            this.btNum7.Click += new System.EventHandler(this.btNum7_Click);
            // 
            // btNum0
            // 
            this.btNum0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum0.Location = new System.Drawing.Point(882, 40);
            this.btNum0.Name = "btNum0";
            this.btNum0.Size = new System.Drawing.Size(75, 44);
            this.btNum0.TabIndex = 12;
            this.btNum0.UseVisualStyleBackColor = true;
            this.btNum0.Click += new System.EventHandler(this.btNum0_Click);
            // 
            // btNum9
            // 
            this.btNum9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNum9.Location = new System.Drawing.Point(801, 40);
            this.btNum9.Name = "btNum9";
            this.btNum9.Size = new System.Drawing.Size(75, 44);
            this.btNum9.TabIndex = 11;
            this.btNum9.UseVisualStyleBackColor = true;
            this.btNum9.Click += new System.EventHandler(this.btNum9_Click);
            // 
            // btNumUp
            // 
            this.btNumUp.Location = new System.Drawing.Point(1044, 40);
            this.btNumUp.Name = "btNumUp";
            this.btNumUp.Size = new System.Drawing.Size(75, 44);
            this.btNumUp.TabIndex = 14;
            this.btNumUp.Text = ">";
            this.btNumUp.UseVisualStyleBackColor = true;
            this.btNumUp.Click += new System.EventHandler(this.btNumUp_Click);
            // 
            // btNumBack
            // 
            this.btNumBack.Location = new System.Drawing.Point(963, 40);
            this.btNumBack.Name = "btNumBack";
            this.btNumBack.Size = new System.Drawing.Size(75, 44);
            this.btNumBack.TabIndex = 13;
            this.btNumBack.Text = "<";
            this.btNumBack.UseVisualStyleBackColor = true;
            this.btNumBack.Click += new System.EventHandler(this.btNumBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(179, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "F1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "F2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(343, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(19, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "F3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(588, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "F6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(502, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "F5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(424, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "F4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(825, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "F9";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(739, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "F8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(661, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "F7";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(909, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "F10";
            // 
            // lblPage
            // 
            this.lblPage.AutoSize = true;
            this.lblPage.Location = new System.Drawing.Point(1020, 87);
            this.lblPage.Name = "lblPage";
            this.lblPage.Size = new System.Drawing.Size(38, 13);
            this.lblPage.TabIndex = 25;
            this.lblPage.Text = "Page: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Chọn:";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1135, 489);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblPage);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btNumUp);
            this.Controls.Add(this.btNumBack);
            this.Controls.Add(this.btNum0);
            this.Controls.Add(this.btNum9);
            this.Controls.Add(this.btNum8);
            this.Controls.Add(this.btNum7);
            this.Controls.Add(this.btNum6);
            this.Controls.Add(this.btNum5);
            this.Controls.Add(this.btNum4);
            this.Controls.Add(this.btNum3);
            this.Controls.Add(this.btNum2);
            this.Controls.Add(this.btNum1);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.rtb_Text);
            this.Name = "frmMain";
            this.Text = "Bộ Gõ Hán Nôm";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmMain_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtb_Text;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btNum1;
        private System.Windows.Forms.Button btNum2;
        private System.Windows.Forms.Button btNum4;
        private System.Windows.Forms.Button btNum3;
        private System.Windows.Forms.Button btNum6;
        private System.Windows.Forms.Button btNum5;
        private System.Windows.Forms.Button btNum8;
        private System.Windows.Forms.Button btNum7;
        private System.Windows.Forms.Button btNum0;
        private System.Windows.Forms.Button btNum9;
        private System.Windows.Forms.Button btNumUp;
        private System.Windows.Forms.Button btNumBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblPage;
        private System.Windows.Forms.Label label10;
    }
}

